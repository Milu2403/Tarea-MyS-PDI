<?php
include('conexion.php');

//recibimos el id por url
$id_empleado = $_GET['id'];

//buscamos el empleado con el legado recibido
$buscar = "SELECT * FROM datos WHERE legajo = '$id_empleado'";

//ejecutamos la consulta
$query = mysqli_query($conexion,$buscar);

//recorremos los resultados y cargamos el form
foreach($query as $res){



?>

<!-- creamos un form para mostrar los datos -->

<html>
    <body>
<form action="actualizar.php" method="post">
        <label for="apellido">Apellido: </label>
        <input type="text" name="apellido" value="<?php echo($res['apellido']);?>">
        
        <br>
        <label for="nombre">Nombres:</label>
        <input type="text" name="nombre" value="<?php echo($res['nombre']);?>">
        
        <br>

        <label for="puesto">Puesto:</label>
        <select name="puesto">
            <option value="2">Administración</option>
            <option value="3">Ventas</option>
            <option value="4">Gerencia</option>
        </select>
        <br>
        <label for="fecha_de_ingreso">Fecha de Ingreso:</label>
        <input type="date" name="fecha_de_ingreso" value="<?php echo($res['fecha_de_ingreso']);?>">
        <br>
        <input type="hidden" name = 'legajo' value='<?php echo($id_empleado);?>'>
        <input type="submit" value="Actualizar">

    </form>

</body>
    </html>


<?php

}
?>