<?php

$conexion=new mysqli("localhost", "root", "", "integradora");

?>