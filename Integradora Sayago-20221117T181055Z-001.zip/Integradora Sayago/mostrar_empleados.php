<?php

include('conexion.php');

$buscar = "SELECT * FROM datos";

$query = mysqli_query($conexion,$buscar);

foreach($query as $res){
    echo("<br>Legajo: ". $res['legajo']);
    echo("<br>Apellido: ". $res['apellido']);
    echo("<br>Nombre: ". $res['nombre']);
    echo("<br>Puesto: ". $res['puesto']);
    echo("<br>Fecha de ingreso: ". $res['fecha_de_ingreso']);
    echo("<hr>");

    $leg = $res ['legajo'];

    echo("<br><a href='modificar.php?id=".$leg."'>Modificar</a>");
    echo(" <a href='eliminar.php?id=".$leg."'>Eliminar</a>");
    echo("<hr>");
}
?>