<?php
include('conexion.php');


//recibimos los datos del form
$Apellido = $_POST['apellido'];
$Nombre = $_POST['nombre'];
$Puesto = $_POST['puesto'];
$fecha_ingreso = $_POST['fecha_de_ingreso'];
$legajo = $_POST['legajo'];

//consulta para hacer update
$actualizar = "UPDATE datos SET apellido = '$Apellido', nombre= '$Nombre', puesto = '$Puesto',fecha_de_ingreso = '$fecha_de_ingreso' WHERE legajo = '$legajo'";

//ejecutamos consulta

$query = mysqli_query($conexion, $actualizar);

if($query){
    echo("Se han actualizado correctamente los datos....");
}
?>