<?php

$Apellido=$_POST['apellido'];
$Nombre=$_POST['nombre'];
$Puesto=$_POST['puesto'];
$fecha_de_ingreso=$_POST['fecha_de_ingreso'];

include('conexion.php');

$alta= "INSERT INTO datos(Apellido,Nombre,Puesto,fecha_de_ingreso)
VALUES('$Apellido','$Nombre','$Puesto','$fecha_de_ingreso')";

if($query= mysqli_query ($conexion, $alta)){
	echo ('Se ha dado de alta correctamente'); 
	
}else{
	echo ('eror al dar de alta...');	
}
echo ("<br><a href='index.html'>Dar de alta otro empleado</a>");
?>