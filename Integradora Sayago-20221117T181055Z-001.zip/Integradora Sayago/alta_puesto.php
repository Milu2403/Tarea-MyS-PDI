<?php

$conexion=new mysqli("localhost", "root", "", "integradora");

$puesto = $_POST['puesto'];
$sueldo = $_POST['sueldo'];

$alta = "INSERT INTO puestos(puesto) VALUES ('$puesto')";

$query = mysqli_query ($conexion,$alta);

if($query){
    echo ("Se ha dado de alta". $puesto);
    echo ("<br><a href='crear_puestos.html'>Volver</a>");
}

?>
